p.tspan=[1790 2000]; %The time span of the solution
p.IC=3.929;          %The initial condition (in 1790)
p.K=300;           %Set the parameters (not really useful here)
p.r=0.5;



